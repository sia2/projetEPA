<?php

	echo 'Vous etes bien arrivé';